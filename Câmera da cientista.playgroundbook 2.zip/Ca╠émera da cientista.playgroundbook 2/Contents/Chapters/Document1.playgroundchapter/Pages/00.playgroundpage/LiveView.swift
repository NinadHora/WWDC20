//
//  LiveView.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import PlaygroundSupport
import SPCCore
import CameraBook

PlaygroundPage.current.liveView = ComponentSpaceViewController(learningTrailEnabled: false)

