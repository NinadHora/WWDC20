//
//  WeakObject.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation

// A generic wrapper class for a weakly referenced object.
// Can be used to store weak object references in a collection.
public class WeakObject<T: AnyObject> {
    weak var object : T?
    init (_ object: T) {
        self.object = object
    }
}
