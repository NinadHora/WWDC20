//
//  CGImage+extensions.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import CoreGraphics

extension CGImage {
    
    public var alphaInfoDescription: String {
        switch self.alphaInfo {
        case .none: return "none e.g. RGB"
        case .premultipliedLast: return "premultipliedLast e.g. premultiplied RGBA"
        case .premultipliedFirst: return "premultipliedFirst e.g. premultiplied ARGB"
        case .last: return "last e.g. non-premultiplied RGBA"
        case .first: return "first e.g. non-premultiplied ARGB"
        case .noneSkipLast: return "noneSkipLast e.g. RBGX"
        case .noneSkipFirst: return "noneSkipFirst e.g. XRGB"
        case .alphaOnly: return "alphaOnly: no color data, alpha data only"
        default:
            return "unknown"
        }
    }
    
    public var hasAlphaChannel: Bool {
        switch self.alphaInfo {
        case .none, .noneSkipLast, .noneSkipFirst: return false
        default: return true
        }
    }
    
    public var description: String {
        let colorSpace = self.colorSpace.debugDescription
        return "\(colorSpace) alpha: \(self.alphaInfoDescription)"
    }
}
