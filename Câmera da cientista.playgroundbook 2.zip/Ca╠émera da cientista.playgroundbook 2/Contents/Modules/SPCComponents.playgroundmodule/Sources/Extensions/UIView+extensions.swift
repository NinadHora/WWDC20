//
//  UIView+extensions.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import UIKit
import SPCCore

extension UIView {
    var ancestorViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            parentResponder = parentResponder!.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
    
    func move(to position: CGPoint, duration: Double, completion: (() -> Void)? = nil) {
        UIView.animate(withDuration: duration,
                       animations: {
                        self.center = position
                        },
                       completion: { _ in
                        completion?()
        })    
    }
}
