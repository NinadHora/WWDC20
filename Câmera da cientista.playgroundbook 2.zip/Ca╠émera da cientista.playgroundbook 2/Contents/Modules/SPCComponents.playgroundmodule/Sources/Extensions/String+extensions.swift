//
//  String+extensions.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation

extension String {
    func lowercasedFirstLetter() -> String {
        return prefix(1).lowercased() + dropFirst()
    }
    
    func trimmingTrailingWhitespaceAndNewlines() -> String {
        let trimmed = ("|" + self).trimmingCharacters(in: .whitespacesAndNewlines)
        return String(trimmed[trimmed.index(after: trimmed.startIndex)...])
    }
}
