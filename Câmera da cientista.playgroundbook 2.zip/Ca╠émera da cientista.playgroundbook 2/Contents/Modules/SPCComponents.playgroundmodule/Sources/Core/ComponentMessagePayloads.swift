//
//  ComponentMessagePayloads.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation
import CoreGraphics
import SPCCore
import PlaygroundSupport

struct ComponentEventPayload : Codable {
    var origin: ComponentMessageOrigin
    var identity : ComponentIdentity
    var event : ComponentEvent
}

struct ComponentInitPayload : Codable {
    var origin: ComponentMessageOrigin
    var type : String
    var identity : ComponentIdentity
}

struct ComponentDeinitPayload : Codable {
    var origin: ComponentMessageOrigin
    var identity : ComponentIdentity
}

struct ComponentSpacePayload : Codable {
    var origin: ComponentMessageOrigin
    var spaceIdentity : ComponentIdentity
}

struct ComponentPayload : Codable {
    var origin: ComponentMessageOrigin
    var componentIdentity : ComponentIdentity
    var spaceIdentity : ComponentIdentity
}

struct ComponentAddPayload : Codable {
    var origin: ComponentMessageOrigin
    var componentIdentity : ComponentIdentity
    var spaceIdentity : ComponentIdentity
    var position : Point
    var size : Size?
}
