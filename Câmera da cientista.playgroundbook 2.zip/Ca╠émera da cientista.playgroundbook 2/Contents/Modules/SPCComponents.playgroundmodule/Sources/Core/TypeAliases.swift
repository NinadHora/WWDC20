//
//  TypeAliases.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import UIKit

// User-facing typealiases

public typealias Pulse = Bool
public typealias Path = UIBezierPath
public typealias Color = UIColor
public typealias Image = UIImage
public typealias ContentMode = UIView.ContentMode
public typealias TextAlignment = NSTextAlignment
