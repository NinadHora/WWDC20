//
//  PhotoCollection.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation
import Photos
import PlaygroundSupport
import SPCCore

/// A photo collection represents a collection of **Photos** photos.
/// It conforms to the Swift `Collection` and `Sequence` protocols so you can use it just like an array. For example:
/// ```
/// let photoCount = photoCollection.count
/// let photo = photoCollection[12]
/// ```
///
/// - localizationKey: PhotoCollection
public class PhotoCollection: PhotoAssetCollection {
    
    /// Creates an empty photo collection.
    ///
    /// - localizationKey: PhotoCollection()
    public override init() {
        super.init()
    }
    
    /// Creates a photo collection to hold a **Photos** photo collection with the specified identifier.
    ///
    /// - Parameter identifier: The identifier of the collection to be loaded.
    ///
    /// - localizationKey: PhotoCollection(identifier:)
    public override init(identifier: String) {
        super.init(identifier: identifier)
    }
}

extension PhotoCollection: PlaygroundValueTransformable {
    
    public var playgroundValue: PlaygroundValue? {
        guard let identifier = self.identifier else { return nil }
        return .string(identifier)
    }
    
    public static func from(_ playgroundValue: PlaygroundValue) -> PlaygroundValueTransformable? {
        guard case .string(let identifier) = playgroundValue, !identifier.isEmpty else { return nil }
        
        return PhotoCollection(identifier: identifier)
    }
}
