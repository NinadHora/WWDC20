//
//  CutsceneHelpers.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import UIKit

public struct CutsceneContentIdentifiers {
    public static let assembleYourCamera = "com.apple.playgrounds.assembleyourcamera"
    public static let flashyPhotos = "com.apple.playgrounds.flashyphotos"
    public static let cameraCreate = "com.apple.playgrounds.cameracreate"
    public static let sonicWorkshop = "com.apple.playgrounds.sonicworkshop"
    public static let sensorArcade = "com.apple.playgrounds.sensorarcade"
}

public func deg2Rad(_ degrees: CGFloat) -> CGFloat {
    return CGFloat.pi * degrees/180
}

public extension CGAffineTransform {
    var rotationAngle: CGFloat {
        return atan2(b, a) * 180 / CGFloat.pi
    }
    
    var scaleX: CGFloat {
        return sqrt(a * a + c * c)
    }
    
    var scaleY: CGFloat {
        return sqrt(b * b + d * d)
    }
}

extension UIImage {
    func scaledToFit(within availableSize: CGSize) -> UIImage {
        var scaledImageRect = CGRect.zero
        
        let aspectWidth = availableSize.width / self.size.width
        let aspectHeight = availableSize.height / self.size.height
        let aspectRatio = min(aspectWidth, aspectHeight)
        
        scaledImageRect.size.width = self.size.width * aspectRatio
        scaledImageRect.size.height = self.size.height * aspectRatio
        
        let rendererFormat = UIGraphicsImageRendererFormat()
        rendererFormat.scale = 1
        
        let renderer = UIGraphicsImageRenderer(size: scaledImageRect.size, format: rendererFormat)
        let scaledImage = renderer.image { _ in
            self.draw(in: scaledImageRect)
        }
        return scaledImage
    }
}
