//
//  CameraFunGlobal.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation
import PlaygroundSupport
import SPCComponents

/// An app with a space for its components.
///
/// - localizationKey: App
public protocol App {
    var space: Space { get }
}

/// Displays the coordinate system grid.
/// Grid lines are shown at 50 point intervals.
///
/// - localizationKey: CameraFunGlobal.showGrid()
public func showGrid() {
    CameraFunMessage.showGrid(origin: ComponentMessageOrigin.current).send(to: .live)
}
