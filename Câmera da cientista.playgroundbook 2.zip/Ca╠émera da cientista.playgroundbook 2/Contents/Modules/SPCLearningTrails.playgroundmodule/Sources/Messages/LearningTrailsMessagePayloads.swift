//
//  LearningTrailsMessagePayloads.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation

struct LearningTrailsOriginPayload: Codable {
    var origin: LearningTrailsMessageOrigin
}
