//  /*#-localizable-zone(PhotoEditorCopyright1)*/Copyright/*#-end-localizable-zone*/ © 2016-2019 Apple Inc. /*#-localizable-zone(PhotoEditorCopyright2)*/All rights reserved./*#-end-localizable-zone*/

import Foundation
import SPCComponents

//#-localizable-zone(StartingPointPhotoEditor01)
// Photo editor component using emoji buttons.
//#-end-localizable-zone
public class PhotoEditor: Space {
//#-localizable-zone(StartingPointPhotoEditor02)
    // Create the components.
//#-end-localizable-zone
    let workspace = Space()
    let imageView = ImageView()
    
    let editButtonA = Button()
    let editButtonB = Button()
    let editButtonC = Button()
    
    let saveButton = Button()
    let clearButton = Button()
    let shareButton = ActivityButton()
    
//#-localizable-zone(StartingPointPhotoEditor03)
    // Create an image input.
//#-end-localizable-zone
    public var input = Input<Image>()
    
//#-localizable-zone(StartingPointPhotoEditor04)
    // Create an image output.
//#-end-localizable-zone
    public var photoSaved = Output<Image>()
    
    public override init() {
        super.init()
        
        backgroundColor =  #colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1)
        borderColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        borderWidth = 4.0
        cornerRadius = 10.0
        
        workspace.borderColor = #colorLiteral(red: 0.95686274766922, green: 0.658823549747467, blue: 0.545098066329956, alpha: 1.0)
        workspace.borderWidth = 4
        
        imageView.image = #imageLiteral(resourceName: "cf_stockPhotoBeachHorsebackRiding_108909_square")
        
//#-localizable-zone(StartingPointPhotoEditor05)
        // Add the components.
//#-end-localizable-zone
        add(workspace, at: Point(x: 0, y: 0), size: Size(width: 200, height: 200))
        workspace.add(imageView, at: Point(x: 0, y: 0), size: Size(width: 200, height: 200))
        add(editButtonA, at: Point(x: -175, y: 75))
        add(editButtonB, at: Point(x: -175, y: 0))
        add(editButtonC, at: Point(x: -175, y: -75))
        add(saveButton, at: Point(x: 175, y: 75))
        add(clearButton, at: Point(x: 175, y: 0))
        add(shareButton, at: Point(x: 175, y: -75))
        
//#-localizable-zone(StartingPointPhotoEditor06)
        // Set the properties of the components.
//#-end-localizable-zone
        setupButton(button: editButtonA, emoji: "🐞")
        setupButton(button: editButtonB, emoji: "🐣")
        setupButton(button: editButtonC, emoji: "🦊")
        setupButton(button: saveButton, emoji: "✅")
        setupButton(button: clearButton, emoji: "❌")
        
//#-localizable-zone(StartingPointPhotoEditor07)
        // Connect the components.
//#-end-localizable-zone
        editButtonA.pressed.connect(to: onEditButtonAPressed)
        editButtonB.pressed.connect(to: onEditButtonBPressed)
        editButtonC.pressed.connect(to: onEditButtonCPressed)
        clearButton.pressed.connect(to: onClearButtonPressed)
        saveButton.pressed.connect(to: onSaveButtonPressed)
        workspace.snapshotTaken.connect(to: onSnapshotTaken)
        workspace.snapshotTaken.connect(to: shareButton.imageInput)
        
//#-localizable-zone(StartingPointPhotoEditor08)
        // Initialize the image input.
//#-end-localizable-zone
        input = Input<Image>({ image in
            self.imageView.image = image
        })
    }
    
//#-localizable-zone(StartingPointPhotoEditor09)
    // Handle edit button presses.
//#-end-localizable-zone
    func onEditButtonAPressed(pulse: Pulse) {
        decorateWithSnowflakes(space: workspace, count: 20)
    }
    
    func onEditButtonBPressed(pulse: Pulse) {
        decorateWithEmojiBorder(space: workspace, emoji: "🐳", count: 10)
    }
    
    func onEditButtonCPressed(pulse: Pulse) {
        decorateWithFlowers(space: workspace, count: 30)
    }
    
//#-localizable-zone(StartingPointPhotoEditor10)
    // Handle clear button presses.
//#-end-localizable-zone
    func onClearButtonPressed(pulse: Pulse) {
//#-localizable-zone(StartingPointPhotoEditor11)
        // Clears all the subcomponents except the image view.
//#-end-localizable-zone
        for component in workspace.subcomponents {
            if component != imageView {
                workspace.remove(component)
            }
        }
    }

//#-localizable-zone(StartingPointPhotoEditor12)
    // Handle snapshot taken events.
//#-end-localizable-zone
    func onSnapshotTaken(image: Image) {
        photoSaved.notifyInputs(image)
    }
    
//#-localizable-zone(StartingPointPhotoEditor13)
    // Handle save button presses.
//#-end-localizable-zone
    func onSaveButtonPressed(pulse: Pulse) {
        workspace.takeSnapshot()
    }
    
//#-localizable-zone(StartingPointPhotoEditor14)
    // Sets up a button with an emoji title.
//#-end-localizable-zone
    func setupButton(button: Button, emoji: String) {
        button.title = emoji
        button.backgroundColor = .clear
        button.scale = 2.0
    }
}

