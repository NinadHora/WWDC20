//  /*#-localizable-zone(DecorateCopyright1)*/Copyright/*#-end-localizable-zone*/ © 2016-2019 Apple Inc. /*#-localizable-zone(DecorateCopyright2)*/All rights reserved./*#-end-localizable-zone*/

import Foundation
import SPCComponents

// -----------------------------------
//#-localizable-zone(StartingPointDecorate01)
// Sticker
//#-end-localizable-zone
// -----------------------------------
public func decorateWithSticker(space: Space) {
//#-localizable-zone(StartingPointDecorate02)
    // Create the sticker.
//#-end-localizable-zone
    let sticker = ImageView()
    
//#-localizable-zone(StartingPointDecorate03)
    // Set the sticker’s properties.
//#-end-localizable-zone
    sticker.image = #imageLiteral(resourceName: "LadyBugButton.png")
    
//#-localizable-zone(StartingPointDecorate04)
    // Add the sticker to the workspace.
//#-end-localizable-zone
    space.add(sticker, at: Point(x: 40, y: 40))
}

// -----------------------------------
//#-localizable-zone(StartingPointDecorate05)
// Label
//#-end-localizable-zone
// -----------------------------------
public func decorateWithLabel(space: Space) {
//#-localizable-zone(StartingPointDecorate06)
    // Create a label and set its text.
//#-end-localizable-zone
    let label = Label()
//#-localizable-zone(StartingPointDecorate07)
    // Edit the string to change the displayed text.
//#-end-localizable-zone
    label.text = "👩‍🦱❤️🐴"
    
//#-localizable-zone(StartingPointDecorate08)
    // Style the label and set other properties.
//#-end-localizable-zone
    let style = TextStyle(.Copperplate, fontSize: 24, color: .orange)
    label.textStyle = style
    label.rotation = 45.0
    label.shadowColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
    label.shadowOffset = Size(width: 1, height: 1)
    
//#-localizable-zone(StartingPointDecorate09)
    // Add the label to the space.
//#-end-localizable-zone
    space.add(label, at: Point(x: 0, y: 0))
}

// -----------------------------------
//#-localizable-zone(StartingPointDecorate10)
// Flower emoji
//#-end-localizable-zone
// -----------------------------------
public func decorateWithFlowers(space: Space, count: Int) {
    let choices = ["🍀", "🌸", "🌼", "🌻", "🌹", "💐"]
    
    let points = randomPointsWithin(space: space, count: count)
    
//#-localizable-zone(StartingPointDecorate11)
    // Add a label at each position.
//#-end-localizable-zone
    for position in points {
        let index = Int.random(in: 0..<choices.count)
        let emoji = choices[index]
        let label = Label()
        label.text = emoji
        label.scale = Double.random(in: 1...2)
        label.rotation = Double.random(in: -30...30)
        space.add(label, at: position)
    }
}

// -----------------------------------
//#-localizable-zone(StartingPointDecorate12)
// Hearts emoji
//#-end-localizable-zone
// -----------------------------------
public func decorateWithHearts(space: Space, count: Int) {
    let choices = ["💙", "🧡", "💛", "💚", "💜", "❤️"]
    
    let points = pointsAroundCornersOf(space: space, count: count)
    
//#-localizable-zone(StartingPointDecorate13)
    // Add a label at each position.
//#-end-localizable-zone
    for position in points {
        let index = Int.random(in: 0..<choices.count)
        let emoji = choices[index]
        let label = Label()
        label.text = emoji
        label.scale = Double.random(in: 1...2.5)
        label.rotation = Double.random(in: -30...30)
        space.add(label, at: position)
    }
}

// -----------------------------------
//#-localizable-zone(StartingPointDecorate14)
// Snowflakes
//#-end-localizable-zone
// -----------------------------------
public func decorateWithSnowflakes(space: Space, count: Int) {
    let choices = ["❅", "❆"]
    
    let points = randomPointsWithin(space: space, count: count)
    
//#-localizable-zone(StartingPointDecorate15)
    // Add a label at each position.
//#-end-localizable-zone
    for position in points {
        let index = Int.random(in: 0..<choices.count)
        let emoji = choices[index]
        let label = Label()
        label.textStyle = TextStyle(.SystemFontRegular, fontSize: 14, color: #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1), alignment: .center)
        label.text = emoji
        label.scale = Double.random(in: 1...4)
        label.rotation = Double.random(in: -30...30)
        label.alpha = Double.random(in: 0.5...1)
        space.add(label, at: position)
    }
}

// -----------------------------------
//#-localizable-zone(StartingPointDecorate16)
// Stars
//#-end-localizable-zone
// -----------------------------------
public func decorateWithStars(space: Space, count: Int) {
    let choices = ["✯", "✷", "✵", "٭"]
    let colors: [Color] = [#colorLiteral(red: 0.9995340705, green: 0.988355577, blue: 0.4726552367, alpha: 1), #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1), #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), #colorLiteral(red: 0.9994240403, green: 0.9855536819, blue: 0, alpha: 1)]
    
    let points = pointsAroundCornersOf(space: space, count: count)
    
//#-localizable-zone(StartingPointDecorate17)
    // Add a label at each position.
//#-end-localizable-zone
    for position in points {
        let index = Int.random(in: 0..<choices.count)
        let emoji = choices[index]
        let colorIndex = Int.random(in: 0..<colors.count)
        let color = colors[colorIndex]
        let label = Label()
        label.textStyle = TextStyle(.SystemFontRegular, fontSize: 14, color: color, alignment: .center)
        label.text = emoji
        label.scale = Double.random(in: 1...4)
        label.rotation = Double.random(in: -30...30)
        label.alpha = Double.random(in: 0.5...1)
        space.add(label, at: position)
    }
}


// -----------------------------------
//#-localizable-zone(StartingPointDecorate18)
// Stickers
//#-end-localizable-zone
// -----------------------------------
public func decorateWithImages(space: Space, count: Int) {
    let images: [Image]  = [#imageLiteral(resourceName: "cf_sticker006"), #imageLiteral(resourceName: "cf_sticker010")]
    
    let points = randomPointsWithin(space: space, count: count)
    
//#-localizable-zone(StartingPointDecorate19)
    // Add a sticker image at each position.
//#-end-localizable-zone
    for position in points {
        let index = Int.random(in: 0..<images.count)
        let image = images[index]
        let sticker = ImageView()
        sticker.image = image
        sticker.scale = Double.random(in: 1...10)
        sticker.rotation = Double.random(in: -30...30)
        sticker.alpha = Double.random(in: 0.5...1)
        space.add(sticker, at: position, size: Size(width: 20, height: 20))
    }
}

// -----------------------------------
//#-localizable-zone(StartingPointDecorate20)
// Emoji Border
//#-end-localizable-zone
// -----------------------------------
public func decorateWithEmojiBorder(space: Space, emoji: String, count: Int) {
    
    let points = pointsAroundBorderOf(space: space, margin: 25, count: count)
    
//#-localizable-zone(StartingPointDecorate21)
    // Add a label at each position.
//#-end-localizable-zone
    for position in points {
        let label = Label()
        label.textStyle = TextStyle(.Georgia, fontSize: 24)
        label.text = emoji
        space.add(label, at: position)
    }
}

